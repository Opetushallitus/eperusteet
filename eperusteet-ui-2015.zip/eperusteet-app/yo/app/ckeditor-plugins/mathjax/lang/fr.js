/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'fr', {
	title: 'Mathématiques au format TeX',
	button: 'Math',
	dialogInput: 'Saisir la formule TeX ici',
	docUrl: 'http://fr.wikibooks.org/wiki/LaTeX/Math%C3%A9matiques',
	docLabel: 'Documentation du format TeX',
	loading: 'chargement...',
	pathName: 'math'
} );
