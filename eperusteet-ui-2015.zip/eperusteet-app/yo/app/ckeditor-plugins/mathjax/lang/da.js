/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'da', {
	title: 'Matematik i TeX',
	button: 'Matematik',
	dialogInput: 'Write your TeX here', // MISSING
	docUrl: 'http://en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'TeX dokumentation',
	loading: 'loading...', // MISSING
	pathName: 'matematik'
} );
