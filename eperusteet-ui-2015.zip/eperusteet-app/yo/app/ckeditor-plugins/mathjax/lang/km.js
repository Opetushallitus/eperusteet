/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'km', {
	title: 'គណិត​វិទ្យា​ក្នុង TeX',
	button: 'គណិត',
	dialogInput: 'សរសេរ TeX របស់​អ្នក​នៅ​ទីនេះ',
	docUrl: 'http://en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'ឯកសារ​អត្ថបទ​ពី ​TeX',
	loading: 'កំពុង​ផ្ទុក..',
	pathName: 'គណិត'
} );
