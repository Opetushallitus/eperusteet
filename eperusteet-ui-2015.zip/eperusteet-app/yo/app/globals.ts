// Temporary workaraund
declare var angular: any;
declare var _: any;
declare var CKEDITOR: any;
declare var XLSX: any;
declare var $q: any;
declare var global: any;
declare var moment: any;
declare var $: any;
declare var window: Window;
