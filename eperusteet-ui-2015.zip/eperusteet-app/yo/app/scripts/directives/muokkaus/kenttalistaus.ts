/*
* Copyright (c) 2013 The Finnish Board of Education - Opetushallitus
*
* This program is free software: Licensed under the EUPL, Version 1.1 or - as
* soon as they will be approved by the European Commission - subsequent versions
* of the EUPL (the "Licence");
*
* You may not use this work except in compliance with the Licence.
* You may obtain a copy of the Licence at: http://ec.europa.eu/idabc/eupl
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* European Union Public Licence for more details.
*/

import * as angular from "angular";
import _ from "lodash";

angular
    .module("eperusteApp")
    .directive("kenttalistaus", ($q, MuokkausUtils, $timeout, FieldSplitter) => {
        return {
            template: require("views/partials/muokkaus/kenttalistaus.html"),
            restrict: "E",
            transclude: true,
            scope: {
                fields: "=",
                objectPromise: "=",
                editEnabled: "=",
                mode: "@?",
                hideEmptyPlaceholder: "@?",
                emptyplaceholder: "@",
                emptyplaceholderedit: "@"
            },
            link: function(scope, element) {
                scope.updateContentTip = function() {
                    $timeout(function() {
                        scope.noContent = element.find("ul.muokkaus").children().length === 0;
                    });
                };
                scope.updateContentTip();
                scope.$watch("editEnabled", function() {
                    scope.updateContentTip();
                });
                scope.$watch(
                    "fields",
                    function() {
                        scope.updateContentTip();
                    },
                    true
                );
            },
            controller: function($scope) {
                let model;
                $scope.noContent = false;
                $scope.expandedFields = $scope.fields;

                $scope.removeField = function(fieldToRemove) {
                    const splitfield = FieldSplitter.process(fieldToRemove);
                    if (splitfield.isMulti()) {
                        splitfield.remove(model);
                    } else {
                        if (_.isFunction(fieldToRemove.remove)) {
                            fieldToRemove.remove();
                        } else {
                            MuokkausUtils.nestedSet(model, fieldToRemove.path, ".", null);
                        }
                        fieldToRemove.visible = false;
                        fieldToRemove.$added = false;
                    }
                    setInnerObjectPromise();
                };

                $scope.getClass = FieldSplitter.getClass;

                $scope.hasEditableTitle = function(field) {
                    return _.has(field, "titleplaceholder");
                };

                function setInnerObjectPromise() {
                    if ($scope.objectPromise) {
                        $scope.innerObjectPromise = $scope.objectPromise.then(function(object) {
                            splitFields(object);
                            model = object;
                            return object;
                        });
                    }
                }

                $scope.$watch("objectPromise", setInnerObjectPromise);
                $scope.$on("osafield:update", setInnerObjectPromise);

                if ($scope.objectPromise) {
                    $scope.innerObjectPromise = $scope.objectPromise.then(function() {
                        setInnerObjectPromise();
                    });
                }

                function splitFields(object) {
                    $scope.expandedFields = [];
                    _.each($scope.fields, function(field) {
                        const splitfield = FieldSplitter.process(field);
                        if (splitfield.isMulti() && splitfield.needsSplit()) {
                            // Expand array to individual fields
                            splitfield.each(object, function(item, index) {
                                if (!item) {
                                    return;
                                }
                                const newfield = angular.copy(field);
                                newfield.path = splitfield.getPath(index);
                                newfield.localeKey = item[field.localeKey];
                                newfield.originalLocaleKey = field.localeKey;
                                newfield.visible = MuokkausUtils.hasValue(object, newfield.path);
                                if (field.isolateEdit && index === field.$setEditable) {
                                    newfield.$editing = true;
                                    delete field.$setEditable;
                                }
                                $scope.expandedFields.push(newfield);
                            });
                        } else {
                            field.inMenu = field.path !== "nimi" && field.path !== "koodiUri";
                            if (field.visibleFn) {
                                field.visible = field.visibleFn();
                            } else {
                                field.visible = field.divider
                                    ? false
                                    : field.$added || field.mandatory || MuokkausUtils.hasValue(object, field.path);
                            }
                            $scope.expandedFields.push(field);
                        }
                    });
                    $scope.updateContentTip();
                }
            }
        };
    })
    .service("FieldSplitter", function() {
        function getCssClass(path) {
            return path
                .replace(/\[/g, "")
                .replace(/]/g, "")
                .replace(/\./g, "");
        }

        function SplitField(data) {
            this.original = data;
            this.parts = [];
        }

        SplitField.prototype.split = function() {
            if (!this.original.path) {
                return;
            }
            this.parts = this.original.path.split("[");
            const index = this.original.path.match(/\[(\d+)]/);
            this.index = index ? index[1] : null;
        };

        SplitField.prototype.isMulti = function() {
            return this.parts.length === 2;
        };

        SplitField.prototype.needsSplit = function() {
            return this.index === null;
        };

        SplitField.prototype.each = function(obj, cb) {
            return _.each(this.getObject(obj), cb);
        };

        SplitField.prototype.getPath = function(index) {
            return this.parts[0] + "[" + index + this.parts[1];
        };

        SplitField.prototype.getObject = function(obj, create) {
            if (create && !obj[this.parts[0]]) {
                obj[this.parts[0]] = [];
            }
            return !obj ? null : obj[this.parts[0]];
        };

        SplitField.prototype.addArrayItem = function(obj) {
            const newItem = _.isFunction(this.original.empty)
                ? this.original.empty()
                : { otsikko: { fi: "" }, teksti: { fi: "" } };
            const object = this.getObject(obj, true);
            object.push(newItem);
            return object.length - 1;
        };

        SplitField.prototype.remove = function(obj) {
            const index = parseInt(this.parts[1], 10);
            obj[this.parts[0]].splice(index, 1);
        };

        SplitField.prototype.getClass = function(index) {
            return getCssClass(this.getPath(index));
        };

        this.process = function(field) {
            const obj = new SplitField(field);
            obj.split();
            return obj;
        };

        this.getClass = function(field) {
            return getCssClass(field.path);
        };
    })
    .factory("ArviointiHelper", function() {
        const remove = function(arr, str) {
            const index = _.findIndex(arr, { path: str });
            if (index >= 0) {
                arr.splice(index, 1);
            }
        };

        /**
     * Arviointi voi olla tekstinä tai taulukkona (mutta ei kumpanakin).
     * createArviointi hanskaa mitä näytetään kenttälistauksessa ja "lisää osio"-menussa
     */
        function createArviointi() {
            const TAULUKKO_PATH = "arviointi.arvioinninKohdealueet";
            const TEKSTI_PATH = "arviointi.lisatiedot";
            const self: any = {};
            self.obj = {};

            self.hasTeksti = function() {
                return self.obj.teksti && self.obj.teksti.visible;
            };

            self.hasTaulukko = function() {
                return self.obj.taulukko && self.obj.taulukko.visible;
            };

            self.initFromFields = function(fields) {
                const obj = {
                    teksti: null,
                    taulukko: null
                };

                _.each(fields, function(field) {
                    if (field.path === TAULUKKO_PATH) {
                        obj.taulukko = field;
                    } else if (field.path === TEKSTI_PATH) {
                        obj.teksti = field;
                    }
                });

                if (self.hasTeksti()) {
                    obj.taulukko.visible = false;
                }

                self.obj = obj;
                return self.obj;
            };

            self.setMenu = function(menu) {
                if (self.exists()) {
                    remove(menu, TAULUKKO_PATH);
                    remove(menu, TEKSTI_PATH);
                }
            };

            self.exists = function() {
                return self.hasTeksti() || self.hasTaulukko();
            };

            return self;
        }

        return {
            create: createArviointi
        };
    })
    .factory("AmmattitaitoHelper", function() {
        const remove = function(arr, str) {
            const index = _.findIndex(arr, { path: str });
            if (index >= 0) {
                arr.splice(index, 1);
            }
        };

        function createAmmattitaito() {
            const TAULUKKO_PATH = "ammattitaito.ammattitaidonKohdealueet";
            const TEKSTI_PATH = "ammattitaito.lisatiedot";
            const self: any = {};
            self.obj = {};

            self.hasTeksti = function() {
                return self.obj.teksti && self.obj.teksti.visible;
            };

            self.hasTaulukko = function() {
                return self.obj.taulukko && self.obj.taulukko.visible;
            };

            self.initFromFields = function(fields) {
                const obj = { teksti: null, taulukko: null };
                _.each(fields, function(field) {
                    if (field.path === TAULUKKO_PATH) {
                        obj.taulukko = field;
                    } else if (field.path === TEKSTI_PATH) {
                        obj.teksti = field;
                    }
                });
                if (self.hasTeksti()) {
                    obj.taulukko.visible = false;
                }
                self.obj = obj;
                return self.obj;
            };

            self.setMenu = function(menu) {
                if (self.exists()) {
                    remove(menu, TAULUKKO_PATH);
                    remove(menu, TEKSTI_PATH);
                }
            };

            self.exists = function() {
                return self.hasTeksti() || self.hasTaulukko();
            };

            return self;
        }

        return {
            create: createAmmattitaito
        };
    })
    .factory("ValmaarviointiHelper", function() {
        const remove = function(arr, str) {
            const index = _.findIndex(arr, { path: str });
            if (index >= 0) {
                arr.splice(index, 1);
            }
        };

        function createValmaarviointi() {
            const TAULUKKO_PATH = "valmaarviointi.ammattitaidonKohdealueet";
            const TEKSTI_PATH = "valmaarviointi.lisatiedot";
            const self: any = {};
            self.obj = {};

            self.hasTeksti = function() {
                return self.obj.teksti && self.obj.teksti.visible;
            };

            self.hasTaulukko = function() {
                return self.obj.taulukko && self.obj.taulukko.visible;
            };

            self.initFromFields = function(fields) {
                const obj = {
                    teksti: null,
                    taulukko: null
                };

                _.each(fields, function(field) {
                    if (field.path === TAULUKKO_PATH) {
                        obj.taulukko = field;
                    } else if (field.path === TEKSTI_PATH) {
                        obj.teksti = field;
                    }
                });

                if (self.hasTeksti()) {
                    obj.taulukko.visible = false;
                }
                self.obj = obj;

                return self.obj;
            };

            self.setMenu = function(menu) {
                if (self.exists()) {
                    remove(menu, TAULUKKO_PATH);
                    remove(menu, TEKSTI_PATH);
                }
            };

            self.exists = function() {
                return self.hasTeksti() || self.hasTaulukko();
            };

            return self;
        }

        return {
            create: createValmaarviointi
        };
    });
