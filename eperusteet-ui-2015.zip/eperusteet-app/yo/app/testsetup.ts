const jquery = require("jquery");
(global as any).$ = jquery;
(global as any).jQuery = jquery;
(window as any).$ = jquery;
(window as any).jQuery = jquery;

// var CKEDITOR = {};

// import * as angular from "angular";
// (global as any).angular = angular;
// import "angular-mocks/angular-mocks";
